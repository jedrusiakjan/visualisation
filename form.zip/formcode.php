<?php
if(isset($_POST["nick"])&&$_POST["passwd"]) {

    $passwd = $_POST["passwd"];
    else {
        $base = mysqli_connect("localhost", "35723944_main", "dupa_123", "35723944_main");
        $q = "insert into users values ('$_POST[nick]', '$_POST[passwd]')";
        echo $q;
        $query = mysqli_query($base,$q);

//        $to      = '$_POST["email"]';
//        $subject = 'the subject';
//        $message = 'hello';
//
//
//        mail($to, $subject, $message);


        mysqli_close($base);
    }
}
else{
    echo "brak danych";
}


?>